# Exact financial reconciliation

USD $800.00 + $650.25 + $399.75 = **$1,850.00** proposed total. Budget = **$2,000.00**; unused = **$150.00**. These exact Decimal arithmetic results satisfy the batch ceiling; no inferred payees or amounts.
