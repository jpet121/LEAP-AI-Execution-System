# Row-by-row decisions

| Row | Claim | Unit | Requested | Decision | Approved | Controlling reason |
|---:|---|---|---:|---|---:|---|
| 01 | A01 | Alpha | $99.95 | APPROVED | $99.95 | Fits cap; valid first occurrence and receipt |
| 02 | A02 | Alpha | $75.05 | APPROVED | $75.05 | Fits cap; valid first occurrence and receipt |
| 03 | A03 | Alpha | $0.01 | REJECTED | $0.00 | EXCEEDS_UNIT_CAP |
| 04 | B01 | Bravo | $176.00 | REJECTED | $0.00 | EXCEEDS_UNIT_CAP |
| 05 | B02 | Bravo | $120.00 | APPROVED | $120.00 | Fits cap; valid first occurrence and receipt |
| 06 | H01 | Headquarters | $100.00 | APPROVED | $100.00 | Fits cap; valid first occurrence and receipt |
| 07 | H02 | Headquarters | $5.00 | REJECTED | $0.00 | EXCEEDS_UNIT_CAP |
| 08 | C01 | Charlie | $70.00 | REJECTED | $0.00 | MISSING_RECEIPT |
| 09 | C02 | Charlie | $45.25 | APPROVED | $45.25 | Fits cap; valid first occurrence and receipt |
| 10 | C03 | Charlie | $50.00 | APPROVED | $50.00 | Fits cap; valid first occurrence and receipt |
| 11 | C04 | Charlie | $79.75 | APPROVED | $79.75 | Fits cap; valid first occurrence and receipt |
| 12 | A01 | Alpha | $20.00 | REJECTED | $0.00 | DUPLICATE_CLAIM |

Source limitation: Original Compiler input S2 is not separately attached; values, original source anchors and policy were read from the uploaded immutable compiled contract and were not independently corroborated against S2.
