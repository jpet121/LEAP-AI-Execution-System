# Rejection explanations and non-disbursement confirmation

- Row 03 (A03, Alpha): **EXCEEDS_UNIT_CAP** — Full claim would exceed the unit’s remaining cap; partial approvals are prohibited.
- Row 04 (B01, Bravo): **EXCEEDS_UNIT_CAP** — Full claim would exceed the unit’s remaining cap; partial approvals are prohibited.
- Row 07 (H02, Headquarters): **EXCEEDS_UNIT_CAP** — Full claim would exceed the unit’s remaining cap; partial approvals are prohibited.
- Row 08 (C01, Charlie): **MISSING_RECEIPT** — Receipt is NO, whereas YES is required.
- Row 12 (A01, Alpha): **DUPLICATE_CLAIM** — Repeated claim ID already encountered in an earlier source row; duplicate precedence controls.

No funds disbursed; no checks issued, accounting writes, external communications, external research or system modifications performed. All approvals are audit classifications, not payments.

Source limitation: Original Compiler input S2 is not separately attached; values, original source anchors and policy were read from the uploaded immutable compiled contract and were not independently corroborated against S2.
