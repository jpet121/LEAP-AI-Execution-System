# Unit reconciliation

| Unit | Cap | Approved total | Rejected rows | Unused balance |
|---|---:|---:|---:|---:|
| Alpha | $175.00 | $175.00 | 2 | $0.00 |
| Bravo | $175.00 | $120.00 | 1 | $55.00 |
| Charlie | $175.00 | $175.00 | 1 | $0.00 |
| Headquarters | $100.00 | $100.00 | 1 | $0.00 |

Source limitation: Original Compiler input S2 is not separately attached; values, original source anchors and policy were read from the uploaded immutable compiled contract and were not independently corroborated against S2.
