# Batch reconciliation

| Metric | Value |
|---|---:|
| Processed rows | 12 |
| Approved rows | 7 |
| Rejected rows | 5 |
| Approved grand total | $570.00 |

Source limitation: Original Compiler input S2 is not separately attached; values, original source anchors and policy were read from the uploaded immutable compiled contract and were not independently corroborated against S2.
