# Per-vendor PASS / FAIL / HOLD classifications

* **ATLAS — HOLD.** M1 verified pass; M2 UNVERIFIED, not a confirmed compliance or failure; M3 verified pass (400 >=365); M4 verified pass ($37,000 <=$40,000). No verified disqualifier, but mandatory M2 not verified.
* **BEACON — FAIL.** M1 verified pass; M2 verified pass; M3 verified pass (730 >=365); M4 verified fail ($44,000 >$40,000). Verified failure controls even when other checks pass.
* **CEDAR — PASS.** M1 verified pass; M2 verified pass; M3 verified pass (365 >=365); M4 verified pass ($39,000 <=$40,000).

Exactly one classification per vendor. No failure was averaged away, no unmet gate was waived, and no evaluation short-circuited.
