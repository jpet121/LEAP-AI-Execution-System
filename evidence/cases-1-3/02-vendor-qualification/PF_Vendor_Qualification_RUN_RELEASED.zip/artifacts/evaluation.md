# Vendor qualification — evidence-based criterion evaluation

Mandatory M1: SAML 2.0 SSO = VERIFIED YES. M2: both application and document data hosted only in the United States = VERIFIED YES. M3: source-verified audit-log retention >=365 days. M4: source-verified annual subscription cost <= USD $40,000. No waiver, averaging, substitution, or external corroboration is allowed. Every vendor has been checked against all four requirements, including any failure or missing verification.

| Vendor | M1: SAML 2.0 SSO | M2: US-only hosting | M3: Audit logs ≥365 days | M4: Annual cost ≤$40,000 |
|---|---|---|---|---|
| ATLAS | VERIFIED PASS (VERIFIED YES) | UNVERIFIED (UNVERIFIED) | VERIFIED PASS (400 days) | VERIFIED PASS ($37,000.00/year) |
| BEACON | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (730 days) | VERIFIED FAIL ($44,000.00/year) |
| CEDAR | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (365 days) | VERIFIED PASS ($39,000.00/year) |

The status of a criterion is a separate evaluation from each vendor's overall status. UNVERIFIED is neither a verified YES nor a verified NO. Source: user-supplied Compiler contract XML, not independently recovered original business request.
