# Complete 3 × 4 evidence-status matrix

| Vendor | M1: SAML 2.0 SSO | M2: US-only hosting | M3: Audit logs ≥365 days | M4: Annual cost ≤$40,000 |
|---|---|---|---|---|
| ATLAS | VERIFIED PASS (VERIFIED YES) | UNVERIFIED (UNVERIFIED) | VERIFIED PASS (400 days) | VERIFIED PASS ($37,000.00/year) |
| BEACON | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (730 days) | VERIFIED FAIL ($44,000.00/year) |
| CEDAR | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (VERIFIED YES) | VERIFIED PASS (365 days) | VERIFIED PASS ($39,000.00/year) |

Overall classifications: **ATLAS HOLD; BEACON FAIL; CEDAR PASS.** All twelve cells preserve source verification status; ATLAS M2 is deliberately UNVERIFIED rather than inferred YES/NO.
